# Vault Cleaner 0.3.7 source for AMO review

The extension/ directory contains the JavaScript, CSS, HTML, manifest, and PNG
assets that are shipped. JavaScript and styles are loaded directly from those
files. No npm dependencies, transpiler, bundler, or post-processing step is
required to package the extension. Some of the original CSS rules use compact
formatting.

## Reproduce the release ZIP

Run the following command from the root of this source archive:

    python3 build.py

On Windows, python build.py also works. The original package was assembled
with Python 3.14 on Windows. The script uses the standard library and works
on Python 3.9+ on Linux, macOS, and Windows. Its output is
dist/Vault-Cleaner-v0.3.7-Firefox-AMO.zip with manifest.json at the archive root.
Compare the extracted files to review the emitted extension. ZIP timestamps
and compression metadata may vary across environments.

The bundled PNG is the release icon and is copied verbatim. The editable
vector used to render that icon is provided as artwork/vault-cleaner.svg.
The vector and build instructions are review inputs outside the runtime ZIP.
The preview/ folder is a demo using sample data and loads its separate
JavaScript files directly.
